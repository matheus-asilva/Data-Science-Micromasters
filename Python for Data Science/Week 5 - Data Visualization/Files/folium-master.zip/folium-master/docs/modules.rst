:mod:`folium`
-------------

.. automodule:: folium.folium
   :members:
   :undoc-members:
   :show-inheritance:


:mod:`map`
----------

.. automodule:: folium.map
   :members:
   :undoc-members:
   :show-inheritance:


:mod:`Vector Layers`
--------------------

.. automodule:: folium.vector_layers
   :members:
   :undoc-members:
   :show-inheritance:


:mod:`Raster Layers`
--------------------

.. automodule:: folium.raster_layers
   :members:
   :undoc-members:
   :show-inheritance:


:mod:`Extra Features`
---------------------

.. automodule:: folium.features
   :members:
   :undoc-members:
   :show-inheritance:
