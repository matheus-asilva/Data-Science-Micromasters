Installing
==========

Requirements
------------
::

 branca, jinja2, requests, and six.

Some functionalities may require extra dependencies
`numpy`, `pandas`, `geopandas`, `altair`, etc.


Installation
------------
::

$ pip install folium

or

::

$ conda install folium -c conda-forge
